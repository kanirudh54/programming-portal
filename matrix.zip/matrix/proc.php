 

<?php
	require_once 'config.php';
	$query = "insert into logs value ('" . time() . "', '$_SERVER[REMOTE_ADDR]', '" . addslashes(print_r($_SESSION, TRUE)) . "', '" . addslashes(print_r($_REQUEST, TRUE)) . "' )";
	DB::query($query);
	if (isset($_SESSION['loggedin']) && ($_SESSION['team']['status'] == 'Admin' || $_SESSION['team']['status'] == 'Problem Setter'))
	{
		if(isset($_POST['removetc'])){
			$tid=$_POST['tid'];
			$prob_id=$_POST['pid'];
			$rem="delete from testcase where id=".$tid.";";
			shell_exec("./rem.py ".$prob_id);
			DB::query($rem);
			$out=shell_exec("./add.py ".$prob_id);
			$prev_q="select input from problems where pid=".$prob_id.";";
			$prev_c=DB::findOneFromQuery($prev_q);
			$updat="update problems set input=".($prev_c['input']-1)." where pid=".$prob_id.";";
			DB::query($updat);
			echo $out;
		}
	else if(isset($_POST['addtc'])){
		$pid=$_POST['probid'];
		if(isset($_FILES['infiles']['name']))
		{
			$valid_uploads=0;
			
			foreach($_FILES['infiles']['tmp_name'] as $key=>$tmp_name){
				$input=addslashes(file_get_contents($_FILES['infiles']['tmp_name'][$key]));
				$output=addslashes(file_get_contents($_FILES['outfiles']['tmp_name'][$key]));
				$extensions=array("txt");
				$in_file_name=$_FILES['infiles']['name'][$key];
				$out_file_name=$_FILES['outfiles']['name'][$key];
				$file_ext_inp=strtolower(end(explode(".",$in_file_name)));
				$file_ext_out=strtolower(end(explode(".",$out_file_name)));
				$count_tc_query="select input from problems where pid=".$pid.";";
				$tc_count_tmp=DB::findOneFromQuery($count_tc_query);
				$tc_count=$tc_count_tmp['input'];
				if($file_ext_out=="txt" && $file_ext_inp=="txt"){
					$input=str_replace("\r", "",$input);
					$output=str_replace("\r","",$output);
					$valid_uploads++;
					
					$insert_tc_query="insert into testcase (probid,input,output) values (".$pid.",'".$input."','".$output."');";
					$get_tc_id_query="SHOW TABLE STATUS like 'testcase';";
					$status=DB::query($get_tc_id_query);
					$pdos=$status->fetch(PDO::FETCH_ASSOC);
					
					$tid=$pdos['Auto_increment'];
					
					DB::query($insert_tc_query);
					$out=shell_exec("./add.py ".$tid." ".($tc_count+$valid_uploads)." ".$pid);
					//echo "./add.py ".$tid." ".($tc_count+$valid_uploads)." ".$pid."<br />";
					//echo $out;

				}


			}
			$update_problems_query="update problems set input=".($tc_count+$valid_uploads)." where pid=".$pid.";";
			DB::query($update_problems_query);

		}
		$query_add_files="insert into testcase set ";
		$url = SITE_URL."/testcase";
		
		?>
		
	<body>
	<script type="text/javascript">
	function post_to_url(path, params, method) {
    	method = method || "post"; // Set method to post by default if not specified.

    	// The rest of this code assumes you are not using a library.
    	// It can be made less wordy if you use one.
    	var form = document.createElement("form");
    	form.setAttribute("method", method);
    	form.setAttribute("action", path);

    	for(var key in params) {
    	    if(params.hasOwnProperty(key)) {
    	        var hiddenField = document.createElement("input");
    	        hiddenField.setAttribute("type", "hidden");
    	        hiddenField.setAttribute("name", key);
    	        hiddenField.setAttribute("value", params[key]);

         	   form.appendChild(hiddenField);
         	}
    	}
   		// alert("here");
   		 document.body.appendChild(form);
    	form.submit();
	} 	
</script>
	<script type='text/javascript'> 
			post_to_url('<?php echo $url; ?>',{pid:<?php echo $pid;?>}) 
	</script>
	
	</body>
	<?php }
?>
<?php
	}
	else 
	{
		 $_SESSION['msg'] = "Access Denied: You need to be administrator or problem setter to access that page.";
    	  redirectTo(SITE_URL);
	}
 ?>
 
