<div >
	<button class="asdf" ></button>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
	
function click()
{
	alert("hello");
}

$(".asdf").on("click",function(){
	alert("hello");
});
alert(jQuery.fn.jquery);

</script>
<?php

?>