#!/usr/bin/python
import MySQLdb as sql
import os,sys 

sql_hostname="127.0.0.1"
sql_hostport=3306
sql_username="root"
sql_password="root"
sql_database="matrix_exp"

path="./judge/io_cache/"


def file_write(data,fileindex,io,probid):
	try:
		f=open(path+io+"_"+str(probid)+"_"+str(fileindex)+".txt",'wr');
		f.write(data.replace("\r",""))
		#print data.replace("\r","")
		f.close()
		#os.system("chmod 777 "+"./judge/io_cache/"+str(probid)+"/"+io+str(filename)+".txt")
	except Exception, e:
		print "Exception :"+str(e)+"\n"

if( len(sys.argv)==2):
	try:
		link = sql.connect(host=sql_hostname,port=sql_hostport,user=sql_username,passwd=sql_password,db=sql_database);
		cursor = link.cursor(sql.cursors.DictCursor)
		cursor.execute("SELECT input,output FROM testcase WHERE probid="+str(sys.argv[1]))
		link.close()
		i = 0
		for i in range(cursor.rowcount):
			run = cursor.fetchone()
			file_write(run['input'],i+1,"Input",sys.argv[1])
			file_write(run['output'],i+1,"Output",sys.argv[1])
			i = i + 1 
		cursor.close()
	except Exception, e:
		print "Exception :"+str(e)+"\n"
else :   # input args are (testcaseid) (number n) (probid)
	try:
		link = sql.connect(host=sql_hostname,port=sql_hostport,user=sql_username,passwd=sql_password,db=sql_database);
		cursor = link.cursor(sql.cursors.DictCursor)
		cursor.execute("SELECT input,output FROM testcase WHERE id="+str(sys.argv[1]))
		link.close()
		i = 0
		for i in range(cursor.rowcount):
			run=cursor.fetchone()
			file_write(run['input'],sys.argv[2],"Input",sys.argv[3])
			file_write(run['output'],sys.argv[2],"Output",sys.argv[3])
			i = i+1
		cursor.close()
	except Exception, e:
		print "Exception :"+str(e)+"\n"