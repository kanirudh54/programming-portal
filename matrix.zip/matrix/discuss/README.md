Question2Answer on GitHub
-------------------------

As of version 1.6.3, all development of [Question2Answer] will take place through GitHub.

The collaborative development process is being managed by [Scott Vivian].

For more information on contributing, please read the [CONTRIBUTING] page.

Thanks and enjoy!

Gideon


[Question2Answer]: http://www.question2answer.org/
[Scott Vivian]: http://www.question2answer.org/qa/user/Scott
[CONTRIBUTING]: https://github.com/q2a/question2answer/blob/master/CONTRIBUTING.md
