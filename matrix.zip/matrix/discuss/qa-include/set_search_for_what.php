<?php
session_start();
$_SESSION['search_for_what'] = $_REQUEST['id'];
?>