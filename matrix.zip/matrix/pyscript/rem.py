#!/usr/bin/python
import os,sys
'''fl=open("in.txt",'w')
fl.write("abs")
fl.close'''
os.system("rm -f in.txt");