<?php
if ($judge['value'] != "Lockdown" || (isset($_SESSION['loggedin']) && $_SESSION['team']['status'] == 'Admin')) {
    if (isset($_GET['page']))
        $page = $_GET['page'];
    else
        $page = 1;
    $tid = $_SESSION['team']['id'];
    $select = "Select *";
    if($_SESSION['team']['status'] == 'Admin')
        $query = "from clar where access = 'Public' and ( pid='0' or pid ='1000') order by time desc";
    else
        $query = "from clar where access = 'Public' and ( pid='0' or pid ='1000') and tid = '$tid' order by time desc";
    $result = DB::findAllWithCount($select, $query, $page, 10);
    $data = $result['data'];
    foreach ($data as $row) {
        $row['query'] = eregi_replace("\n", "<br>", $row['query']);
        $row['reply'] = eregi_replace("\n", "<br>", $row['reply']);
        $query = "Select teamname from teams where tid = $row[tid]";
        $team = DB::findOneFromQuery($query);
        echo "<div class='post'><b><a href='" . SITE_URL . "/teams/$team[teamname]'>$team[teamname]</a> : $row[query]</b>" . (($row['reply'] != "") ? ("<hr/>Admin:: $row[reply]<br/>") : ('')) . "</div>";
    }
    if (isset($_SESSION['loggedin'])&& $_SESSION['team']['status'] != 'Admin') {
        ?>
        <hr/>
        <h4>Please feel free to post your suggestions and suggestions..<br/>We will reply as soon as we can!</h4>
        <form action="<?php echo SITE_URL; ?>/process.php" method="post">
            <input type="hidden" value="1000" name="pid" />
            <textarea class='form-control' style="width: 500px; height: 200px;" name="query"></textarea><br/>
            <input name="clar" type="submit" class="btn btn-primary" />
        </form>
        <?php
    }
    pagination($result['noofpages'], SITE_URL . "/contact", $page, 10);
} else {
    echo "<br/><br/><br/><div style='padding: 10px;'><h1>Lockdown Mode :(</h1>This feature is now offline as Judge is in Lockdown mode.</div><br/><br/><br/>";
}
?>
