<?php
if ($judge['value'] != "Lockdown" || (isset($_SESSION['loggedin']) && $_SESSION['team']['status'] == 'Admin')) {
    ?>
    <script type='text/javascript' src='<?php echo SITE_URL; ?>/codemirror/lib/codemirror.js'></script>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/codemirror/lib/codemirror.css">
    <script src="<?php echo SITE_URL; ?>/codemirror/mode/javascript/javascript.js"></script>
    <script src="<?php echo SITE_URL; ?>/codemirror/mode/clike/clike.js"></script>
    <script src="<?php echo SITE_URL; ?>/codemirror/mode/pascal/pascal.js"></script>
    <script src="<?php echo SITE_URL; ?>/codemirror/mode/perl/perl.js"></script>
    <script src="<?php echo SITE_URL; ?>/codemirror/mode/php/php.js"></script>
    <script src="<?php echo SITE_URL; ?>/codemirror/mode/python/python.js"></script>
    <script src="<?php echo SITE_URL; ?>/codemirror/mode/ruby/ruby.js"></script>
    <script src="<?php echo SITE_URL; ?>/codemirror/addon/edit/closebrackets.js"></script>
    <script src="<?php echo SITE_URL; ?>/codemirror/addon/edit/matchbrackets.js"></script>
    <script type='text/javascript'>
        $(document).ready(function() {
            var myCodeMirror = CodeMirror.fromTextArea(document.getElementById('sub'), {'matchBrackets': true, 'autoCloseBrackets': true, 'lineWrapping': true, 'mode': 'text/x-c++src', 'lineNumbers': true});
            var cmmode = {"C++":"text/x-c++src","Brainf**k":"text/x-c++src","C":"text/x-csrc","C#":"text/x-csharp","Java":"text/x-java","JavaScript":"text/javascript","Pascal":"text/x-pascal","Perl":"text/x-perl","PHP":"text/x-php","Python":"text/x-python","Ruby":"text/x-ruby","Bash":"text/x-sh","AWK":"text","Text":"text"};
            //alert(<?php echo $cmmode; ?>);
            
            $('#lang').change(function() {
                myCodeMirror.setOption('mode', cmmode[$('#lang').val()]);
                //alert(cmmode[$('#lang').val()]);
            });
        });
    </script>
    <?php
    if (!isset($_SESSION['loggedin'])) {
        echo "<br/><br/><br/><div style='padding: 10px;'><h1>You are not logged in! :(</h1>You need to be logged in to submit a solution.</div><br/><br/><br/>";
    } else {
        if ('1'=='1') {
            if (1==1) {
                echo "<h1>Compile Online</h1>";
                ?>
                <form id='form' action='<?php echo SITE_URL; ?>/compile.php' method='post' enctype='multipart/form-data'>
                    <table class='table table-striped'>
                        <tr><th>Language : </th>
                            <td>
                                <select class="form-control" id='lang' name='language'>
                                    <?php
                                    
                                    foreach ($valtoname as $row) {
                                        if ($row == 'Brain')
                                            echo "<option value='$row'>Brainf**k</option>";
                                        else if ($row == 'C++')
                                            echo "<option value='$row' selected='selected'>$row</option>";
                                        else
                                            echo "<option value='$row'>$row</option>";
                                    }
                                    ?>

                                <select class="form-control" id='lang' name='lang'>
                            
                                </select>    
                            </td><th></th><td></td></tr>
                        <tr><td colspan='4' style='padding: 0;'><textarea id='sub' name='code'><?php
                                    if (isset($_SESSION['subcode'])) {
                                        echo stripslashes($_SESSION['subcode']);
                                        unset($_SESSION['subcode']);
                                    }
                                    ?></textarea></td></tr>
                    </table>
                    <input type="hidden" value="true" name="compile"/>
                    <input type="hidden" value="<?php echo $_SESSION['team']['id'] ?>" name="team_id"/>

                    <b style="margin-left:25px">Input (stdin)</b><br>
                    <textarea class='form-control' style="width: 750px; height: 200px; margin-left: 25px" name="input"></textarea><br>
                    <input type='submit' value='Submit' class='btn btn-large btn-primary' name='submitcode' style="margin-left: 25px"/>
                </form> 
                <?php
            } else {
                echo "<br/><br/><br/><div style='padding: 10px;'><h1>Problem Inactive :(</h1>You cannot submit you solution at this time.</div><br/><br/><br/>";
            }
        } else {
            echo "<br/><br/><br/><div style='padding: 10px;'><h1>Page not Found :(</h1>The page you are searching for is not on this site.</div><br/><br/><br/>";
        }
    }
} else {
    echo "<br/><br/><br/><div style='padding: 10px;'><h1>Lockdown Mode :(</h1>This feature is now offline as Judge is in Lockdown mode.</div><br/><br/><br/>";
}
?>