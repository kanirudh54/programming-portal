<head>
	<style type="text/css">
		.hideContent {
    		overflow: hidden;
    		line-height: 1em;
    		height: 2em;
		}
		.showContent {
    		line-height: 1em;
    		height: auto;
		}
		.showContent{
    		height: auto;
		}
		.show-more {
    		padding: 10px 0;
    		text-align: center;
		}
	</style>
	<script type="text/javascript" src="js/jquery-ui.js" ></script>
	

</head>
<?php
//echo $_GET['mod'];
if(isset($_POST['pid'])){
	$pid=$_POST['pid'];
	$owner_query="select tid from problems where  pid=".$pid;
    $owner_query_result=DB::findOneFromQuery($owner_query);
    $owner=$owner_query_result['tid'];
    //echo $owner." ".$_SESSION['team']['id'];
if (isset($_SESSION['loggedin']) && (($_SESSION['team']['id']==$owner && $_SESSION['team']['status'] == 'Problem Setter') || $_SESSION['team']['status'] == 'Admin'))
 {
		// Add check if the problem setter added the problem
	//$pid=1;
	$query="select name from problems where pid=".$pid;
	$problem=DB::findOneFromQuery($query);
	echo "<center><h1>".$problem['name']."<h1></center>";
	echo "<center><h2>Test Cases</h2></center>";
	
	$query_test="select id,input,output from testcase where probid=".$pid;

	$test_cases=DB::findAllFromQuery($query_test);
	$i=1;
	//echo  $query_test;
	echo "<div class='table-responsive'>";
	echo "<table id='tab' class='table table-bordered'><tr><th>Input</th><th>Output</th><th>Delete</th></tr>";
	
	foreach ($test_cases as $test) {
		# code...
		
		echo "<tr><td class='active' ><div class='content hideContent'>".str_replace("\n","<br \>",$test['input'])."</div> <div class='show-more'><a href='#'>Show more</a> </div></td><td class='active'><div class='content hideContent'>".str_replace("\n","<br \>",$test['output'])."</div><div class='show-more'><a href='#'>Show more</a> </div></td><td class='danger'><button class='btn btn-danger rem' id='del_$test[id]' >Delete</button></td></tr>";
	}
	echo "</table>";
	echo "</div>";


?>
	<center>
		<form action="<?php echo SITE_URL; ?>/proc.php" method="post" class="form-inline" enctype="multipart/form-data">
				<input type='hidden' name="probid" value='<?php echo $pid; ?>' />
				<input type='hidden' name='addtc' value="yes" />
				<table class="table table-bordered" id="test">
					<th>Input</th><th>Output</th>
						<!--<div id="addfiles">
						</div>-->
				</table>
				<button class="add" title="Add a test case file" background-color="white"><img src="img/add-2-icon.png" height="42" width="42" /></button>
			<!--<input type="button" value="Add Testcase" class="btn btn-primary" id="add" onclick="add()" />-->
			<input	type="submit" name="submit" class="btn btn-primary" value="Upload New Files" />
		</form>
	</center>


<script>

	 		$('.add').on("click",function(){
				$('#test').append('<tr><td><input type="file" name="infiles[]" required/></td><td><input type="file" name="outfiles[]" required/></td><td><button  class="btn btn-info" id="remove"><img src="img/wpid-remove.png" height="30" width="30" /></button></td></tr>');

			});
			$('#test').on("click","#remove",function(event){
				event.preventDefault();
				var tr=$(this).closest('tr');
				tr.fadeOut(400, function(){
            			tr.remove();
       			 });
				//alert("clicked");
				
			});
			$('#tab').on("click"," .rem",function(event){
				var id = event.target.id;
				id =id.replace('del_', '');
				var rowCount = $('#tab tr').length;
				//alert(rowCount);
				if(rowCount>2)
				{
					$.post("<?php echo SITE_URL; ?>/proc.php", {
						"removetc":"yes",
						"tid":id,
						"pid":<?php echo $pid ;?>
					},function(result) {
            	            console.log(result);
            	            
            	            //location.reload();
            	       });
						var tr=$(this).closest('tr');
							tr.fadeOut(400, function(){
            					tr.remove();
       				 		});

				/*$.ajax({
					url:"<?php echo SITE_URL ;?>/proc.php",
					type:"post",
					data:{"removetc":"yes",
					"tid":id,
					"pid":<?php echo $pid ;?>,
				},function(result) {
                        if (result === '1') {
                        	alert("Hi");
                        }
				}).done(function(){
					console.log("Done");
				}).fail(function(){
					console.log("Fail");
				});*/
				}
			});
			 
</script>
<script type="text/javascript">
	 $(".show-more a").on("click",function() {
	       
		    var $this = $(this); 
    		var $content = $this.parent().prev("div.content");
        	var linkText = $this.text().toUpperCase();    
        
      	 	 if(linkText === "SHOW MORE"){
      	      linkText = "Show less";
      	      $content.switchClass("hideContent", "showContent", 100);
      	  } else {
      	      linkText = "Show more";
      	      $content.switchClass("showContent", "hideContent", 100);
     	   }
    
     	   $this.text(linkText);
    	});
</script>		
<?php
}
	else{
		  $_SESSION['msg'] = "Access Denied: You need to be administrator or problem setter to access that page.";
    	  redirectTo(SITE_URL);
	}
}
else
{
	$_SESSION['msg'] = "Unauthorized Access. ";
   	redirectTo(SITE_URL);
}
?>	
	   
