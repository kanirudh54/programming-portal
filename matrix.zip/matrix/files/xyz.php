
<?php
                    $query = 'select * from tutorials';
                    $result = DB::findAllFromQuery($query);
                    $id = $row['id'];
                      
                   echo '<h1> Tutorials! </h1><hr/>';
                   //echo "<form method = 'post' action = '" . SITE_URL . "/tut_show'>";
                    foreach($result as $row){ 
                    //echo "<li>" . "<option value='$row[gid]'".(($team['gid'] == $row['gid'])?("selected='selected'"):("")).")>$row[title]</option>" . "</li>";
                    
                    //$strlink = "<a id = " . $row['id'] . " href = '" . SITE_URL . "/tut_show '>" . $row['title'] . "</a>";
                       
                    $strlink = "<a  class = 'add' id = " . $row['id'] .">" . $row['title'] . "</a>";

                    //$strlink = "<li><a href = '" . SITE_URL . "/tut_show'>". $row['title'] ."</a></li>";
                    echo "<li>" . $strlink . "</li>";
                    echo "</form>";
                    }
?>

<?php
if (isset($_SESSION['loggedin']) && $_SESSION['team']['status'] == 'Admin') { ?>
<hr/><h3>Add Tutorial</h3>
<form class="form-horizontal" role='form' method="post" action="add_tut">
        <div class="form-group">
            <label class='control-label col-lg-2' for='title'>Enter Title</label>
            <div class='col-lg-4'><input class='form-control' type="text" name="title" id="title" /></div>
        </div>
        <div class="form-group">
            <label class='control-label col-lg-2' for='content'>Content</label>
            <div class='col-lg-8'><textarea class='form-control' style="width: 550px; height: 400px;" name="content" id="content"></textarea></div>
        </div>
        <div class="form-group">
            <label class='control-label col-lg-2'></label>
            <div class='col-lg-4'><input type="submit" name="add" value="Add" class="btn btn-primary"/></div>
          <!----  <div class='col-lg-4'><input type="file" name="content1" id="content1" class="btn btn-primary"/></div>------>
        </div>
    </form>
            <?php
   
    }
?>
  
<script type="text/javascript">

	 		$('.add').on("click",function(event){
                            event.preventDefault();
                            var id = event.target.id;
                            //alert(id);
                            post_to_url('<?php echo SITE_URL."/tut_show"?>',{"id":id});
			});
				 
</script>

<script type="text/javascript">
	function post_to_url(path, params, method) {
    	method = method || "post"; // Set method to post by default if not specified.

    	// The rest of this code assumes you are not using a library.
    	// It can be made less wordy if you use one.
    	var form = document.createElement("form");
    	form.setAttribute("method", method);
    	form.setAttribute("action", path);

    	for(var key in params) {
    	    if(params.hasOwnProperty(key)) {
    	        var hiddenField = document.createElement("input");
    	        hiddenField.setAttribute("type", "hidden");
    	        hiddenField.setAttribute("name", key);
    	        hiddenField.setAttribute("value", params[key]);

         	   form.appendChild(hiddenField);
         	}
    	}
   		// alert("here");
   		 document.body.appendChild(form);
    	form.submit();
	} 	
</script>