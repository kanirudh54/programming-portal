<?php 
if ($judge['value'] != "Lockdown" || (isset($_SESSION['loggedin']) && $_SESSION['team']['status'] == 'Admin')) {
   // echo "error";
    ?>
    <center><h1><?php echo $_GET['code'];?></h1></center>
    <center><h2>Ranking</h2></center>
<?php

	echo "SELECT tid, count(distinct(runs.pid)) as count FROM runs,problems,contest WHERE contest.name='".$_GET['code']."'' and runs.result='AC' and problems.status!='Deleted' and runs.pid = problems.pid and problems.pgroup=contest.code  and submittime<=endtime ORDER by score DSC, penalty asc";
	//$result=DB::findAllFromQuery($query);
	//echo $query;
	//echo "<br />";
	echo "<table class='table table-hover'><tr><th>Rank</th><th>Name</th><th>Score</th></tr>"; 
	/*$i=1;
	foreach ($result as $val) {
		echo "<tr><td>".$i++."</td><td>$res["
	}*/
	echo "</table>";

//	$query="SELECT tid, count(distinct(runs.pid)) as count, submittime, endtime ,code , contest.name as cname FROM runs,problems,contest WHERE cname=$_GET['code'] and runs.result='AC' and problems.status!='Deleted' and runs.pid = problems.pid and problems.pgroup=code  and submittime<=endtime ORDER by score DSC, penalty asc";
} ?>