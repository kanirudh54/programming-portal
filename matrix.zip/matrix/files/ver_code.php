<?php 
if(!@mysql_connect('localhost', 'root', 'root') || !@mysql_select_db('matrix_exp')){
		echo '<font style="color: white; position: relative; top: 5px;">'; 
		echo 'Incorrect Server Settings';
		echo '</font>';
	}
?>
<?php

$GLOBAL['text']='';
$GLOBAL['webmail_id']='';
//session_start();
				if(isset($_POST['get_webmail']) && !empty($_POST['get_webmail']))
				{
				$webmail=$_POST['get_webmail'];
				$query= "SELECT * FROM `teams` WHERE `email1`= '".$webmail."'"; 
					if($query_run= mysql_query($query)){
								if(mysql_num_rows($query_run)==1)
								{
								$webmail_id= $webmail;
								$rand=rand(10000000, 99999999);
								if(mysql_query("UPDATE  `matrix_exp`.`teams` SET  `vercode` =  '".$rand."' WHERE  `teams`.`email1` ='".$webmail."'")){
								$text= 'Your verification code is '.$rand.'.'."\n\n".'Open '.$_SESSION['url'].'/change_password.php to set your new password.'."\n\n\n";
								
								
								}
								
								
								
								}
				}
				}

echo '
								
								<div class="col-md-5" style="padding:50px;float:center" align="center" >
								<form action="http://email.programmingportal.comuf.com/mail.php" method="POST">
										The verification code will be sent to your webmail. Make sure you have a working Internet Connection.<br>
										<input type="submit" class="btn btn-primary btn-block" value="Send the mail."  >
										<input type="hidden" name="post" value="'.$text.'">
										<input type="hidden" name="webmail" value="'.$webmail_id.'">
										<input type="hidden" name="redirect" value="">
										<br>
										
										
								</form>
										<button class="btn btn-primary btn-block" class="click" onClick=window.location.assign("home")>I\'ll come back later.</button> <br>
								</div>';
		

?>