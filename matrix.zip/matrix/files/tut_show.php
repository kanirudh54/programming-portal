
<?php
                    require_once 'config.php';
                    if(isset($_POST["id"])){
                        
                    $id = $_POST["id"];
                    $query = "select * from tutorials where id=". $id;
                    $result = DB::findAllFromQuery($query);
                    
                    foreach($result as $row){
                    
                    echo "<h1>" . $row['title'] . "</h1>";
                    
//-----------------------------Checking for Admin login for displaying remove feature-----------------------------------------------------------------                    
                    if(isset($_SESSION['loggedin']) && $_SESSION['team']['status']=='Admin'){
                        if(isset($_POST['remove'])){
                            $q = "DELETE FROM `tutorials` WHERE id = " . $_POST['id'];
                            DB::query($q);
                            //redirectTo(SITE_URL . "/xyz");
                            ?>
<!----------------------------Below  this link redirect to xyz.php------------------------------------------------------------------------------------->
<a class="remove_1" href= <?php echo SITE_URL . "/xyz"; ?> > This tutorial has been removed from list!...  </a>
<?php                                                 }  ?>
<!---------------------------------Below form post the current tutorial_id for removing...-------------------------------------------------------------->
<form method="post" action=<?php echo SITE_URL . "/tut_show"; ?>>
        <div class="remove_1">
            <label class='control-label col-lg-2'></label>
            <input type="hidden" name="id" value="<?php echo $id; ?>"/>
            <div class='remove_1' ><input type="submit" name="remove" value="remove" class="btn btn-primary"/></div>
           </div>
</form>

<?php
                        } 
                    echo  "<hr/>" . $row['content'] . "<hr/>";            // this display the content of the current tutorial
                    }
                    }
                    
                ?>

<div>
<?php if (!isset($_SESSION['loggedin'])){
    echo "<h4>For comment's you need to login !</h4>";
                                        }
 ?>    
<?php include  "contact1.php" ;?>
<br></br>
</div>

    