<?php       


if($_POST['title']!=NULL && $_POST['content']!=NULL){
            $title = addslashes($_POST['title']);
            $content = addslashes($_POST['content']);
            
            $query = "insert into tutorials values ('','" . $title . "','" . $content . "')";
            DB::query($query);
?>
            <a href= <?php echo SITE_URL . "/xyz"; ?> > Tutorial added!...  </a>
<?php       

            }
            else{
?>            
            <a href= <?php echo SITE_URL . "/xyz"; ?> > Tutorial title or content is empty!... </a>
<?php } ?>
