<?php
if (isset($_SESSION['loggedin']) && $_SESSION['team']['status'] == 'Admin') {
    $query = "select * from admin";
    $result = DB::findAllFromQuery($query);
    $admin = Array();
    foreach ($result as $row) {
        $admin[$row['variable']] = $row['value'];
    }
    ?>
    <script type='text/javascript'>
        $(document).ready(function() {
            $('#endtime').focus(function() {
                $('#endtime').tooltip('show');
            });
            $('#endtime').blur(function() {
                $('#endtime').tooltip('hide');
            });
        });
    </script>
    <center><h1>Judge Settings</h1></center>
    <script type="text/javascript">
        function validateGenSet()
        {

            var x=validateEndtime();
            var y=validatePenalty();
            if(!(x&&y))
                alert("Here Gen");
            return x&&y;
        } 
        function validateEndtime()
        {
             var x=document.forms["genform"]["endtime"].value;
            if(x)
            {
                if (isNaN(x) || x<0)
                {
                    alert("End Time must be a positive integer");
                    return false;
                }
            }
             return true; 
        }
        function validatePenalty()
        {
             var x=document.forms["genform"]["penalty"].value;
             if(x)
             {
                if (isNaN(x) || x<0)
                {
                    alert("Penalty must be a non negative integer");
                    return false;
                }
            }
             return true;    
        }
        function validateSocket()
        {
            var x=validatePort();
            var y=validateIp();
            return (x&&y);
        }
        function validatePort()
        {
            var port=document.forms["socform"]["port"].value;
            if(isNaN(port) || port<0)
            {
                alert("Port number should be between 0 and 65535");
                return false;
            }
            if(port) return true;
            return false;
        }
        function validateIp()
        {
            var ip=document.forms["socform"]["ip"].value;
            if(!(/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ip)))
            {
                alert("Invalid IP");
                return false;
            }
            return true;
        }
    </script>
    <h3>General Settings</h3>
    <form name="genform" role='form' class="form-horizontal" method="post" onsubmit="return validateGenSet()" action="<?php echo SITE_URL; ?>/process.php">
        <div class="form-group">
            <label class='col-lg-2 control-label' for='judgemode'>Mode</label>
            <div class='col-lg-4'>
                <select class='form-control' name='mode' id='judgemode'>
                    <option value='Active' <?php
                    if ($admin['mode'] == "Active") {
                        echo "selected='selected'";
                    }
                    ?> >Active</option>
                    <option value='Passive' <?php
                    if ($admin['mode'] == "Passive") {
                        echo "selected='selected'";
                    }
                    ?> >Passive</option>
                    <option value='Disabled' <?php
                    if ($admin['mode'] == "Disabled") {
                        echo "selected='selected'";
                    }
                    ?> >Disabled</option>
                    <option value='Lockdown' <?php
                    if ($admin['mode'] == "Lockdown") {
                        echo "selected='selected'";
                    }
                    ?> >Lockdown</option>
                </select>
            </div>
        </div>
        <div class='form-group'>
            <label class='control-label col-lg-2' for='endtime'>End Time</label>
            <div class='col-lg-4'>
                <div class="input-group">
                    <input class='form-control' type='number' min="0" step="1" id='endtime' name='endtime'  data-placement='right' title='Sets the timers equal to no of minutes.' <?php
                    if ($admin['mode'] == 'Active') {
                        echo "value='" . ((int) (($admin['endtime'] - time()) / 60)) . "'";
                    }
                    ?>/>
                    <span class="input-group-addon">minute(s)</span>
                </div>
            </div>
        </div>
        <div class='form-group'>
            <label class='control-label col-lg-2' for='penalty'>Penalty</label>
            <div class='col-lg-4'>
                <div class="input-group">
                    <input class='form-control' type='number' min="0" step="1" id='penalty' name='penalty' value='<?php echo $admin['penalty']; ?>'/>
                    <span class="input-group-addon">minute(s)</span>
                </div>
            </div>
        </div>
        <div class='form-group'>
            <label class='control-label col-lg-2'></label>
            <div class='col-lg-4'>
                <input type='submit' class='btn btn-primary' value='update' name='judgeupdate'/> 
            </div>
        </div>
    </form>
    <h3>Socket Settings</h3>
    <form name="socform"  onsubmit="return validateSocket()" class="form-horizontal" role='form' method="post" action="<?php echo SITE_URL; ?>/process.php">
        <div class="form-group">
            <label class='control-label col-lg-2' for='ip'>IP</label>
            <div class='col-lg-4'><input class='form-control' type="text" name="ip" id="ip" value="<?php echo $admin['ip'] ?>" /></div>
        </div>
        <div class="form-group">
            <label class='control-label col-lg-2' for='port'>Port</label>
            <div class='col-lg-4'><input class='form-control' type="text" name="port" id="port" value="<?php echo $admin['port'] ?>" /></div>
        </div>
        <div class="form-group">
            <label class='control-label col-lg-2'></label>
            <div class='col-lg-4'><input type="submit" name="judgesocket" value="Update Socket" class="btn btn-primary"/></div>
        </div>
    </form>
    <h3>Notice</h3>
    <form class="form-horizontal" role='form' method="post" action="<?php echo SITE_URL; ?>/process.php">
        <div class="form-group">
            <label class='control-label col-lg-2' for='notice'>Notice</label>
            <div class='col-lg-8'><textarea class='form-control' style="width: 550px; height: 400px;" name="notice" id="notice"><?php echo $admin['notice']; ?></textarea></div>
        </div>
        <div class="form-group">
            <label class='control-label col-lg-2'></label>
            <div class='col-lg-4'><input type="submit" name="judgenotice" value="Update Notice" class="btn btn-primary"/></div>
        </div>
    </form>
    <?php
} else {
    $_SESSION['msg'] = "Access Denied: You need to be administrator to access that page.";
    redirectTo(SITE_URL);
}
?>