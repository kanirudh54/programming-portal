<?php
//echo "Hii";
if (isset($_SESSION['loggedin']) && ( $_SESSION['team']['status'] == 'Admin' || $_SESSION['team']['status'] == 'Problem Setter' || $_SESSION['team']['status'] == 'Normal' ) )
{
		echo "<center><h1>My Stats</h1></center>";
        $tid=$_SESSION['team']['id'];
        $query = "select * from runs where tid=$tid ";
        $result = DB::findAllFromQuery($query);
        echo "<table class='table table-hover'>
            <tr><th>Problems Solved</th><th>Solution submitted</th><th>Solution Accepted</th><th>Wrong Ans</th><th>Compile Error</tr>";
        $a=0;//pid checker
        $b=0;//total no. of solutions submitted
        $c=0;//no. of accepted solutions
        $d=0;//total no. of problems
        $e=0;//total no. of wrong answers
       foreach ($result as $row) {

            //echo "<tr><td><a href='" . SITE_URL . "/contests/$row[code]'>$row[code]</a></td><td><a href='" . SITE_URL . "/contests/$row[code]'>$row[name]</a></td><td><a href='" . SITE_URL . "/contests/$row[code]'>" . date("d-M-Y, h:i:s a", $row['starttime']) . "</a></td><td><a href='" . SITE_URL . "/contests/$row[code]'>" . date("d-M-Y, h:i:s a", $row['endtime']) . "</a></td></tr>";
        if ($a == $row[pid]){
        if($row[result] == 'AC'){
        	$b=$b+1;
        	$c=$c+1;

        }
         else if($row[result] == 'WA')
         {
            $b=$b+1;
            $e=$e+1;
        }
        else {
        	$b=$b+1;
        }
        }
        else {
		$d=$d+1;
		if($row[result] == 'AC'){
			$b=$b+1;
			$c=$c+1;
		}
        else if($row[result] == 'WA')
         {
            $b=$b+1;
            $e=$e+1;
        }
        else {
        	$b=$b+1;
        }
		}
		$a=$row[pid];
		}
		$m=$b-$c-$e;
		echo "<tr><td>$d</td><td>$b</td><td>$c</td><td>$e</td><td>$m</td></tr>";
        echo "</table>";

       // echo "<center><h1>My Stats</h1></center>";
        $tid=$_SESSION['team']['id'];
        $query = "select * from runs where tid=$tid ";
        $result = DB::findAllFromQuery($query);
        echo "<table class='table table-hover'>
            <tr><th>Language</th><th>No. of solutions</th></tr>";
             $a=0; $b=0;$c=0;$d=0;$e=0;$f=0;$g=0;
             $sub=array("C"=>"0","C++"=>"0","Python"=>"0","Java"=>"0","Pascal"=>"0","Perl"=>"0","PHP"=>"0","C#"=>"0","JavaScript"=>"0","Python3"=>"0","Ruby"=>"0","AWK"=>"0","Bash"=>"0");
        
        foreach($sub as $x=>$x_value)
        {
            foreach ($result as $row) {
                if($row["language"] == $x)
                {
                    $x_value++;
                }
            }
            if($x_value != 0)
                echo "<tr><td>$x</td><td>$x_value</td></tr>";
            //echo $x_value;    
         }     
        echo "</table>";


}
else {
    echo "<br/><br/><br/><div style='padding: 10px;'><h1>Lockdown Mode :(</h1>This feature is now offline as Judge is in Lockdown mode.</div><br/><br/><br/>";
}
?>