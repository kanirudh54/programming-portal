<?php 
if(!@mysql_connect('localhost', 'root', 'root') || !@mysql_select_db('matrix_exp')){
		echo '<font style="color: white; position: relative; top: 5px;">'; 
		echo 'Incorrect Server Settings.';
		echo '</font>';
	}
?>
<?php
session_start();
$change=0;
				if(isset($_POST['ver_code']) && isset($_POST['new_pass']) && isset($_POST['new_pass_again']) && isset($_POST['webmail_id']))
				{
				$webmail=$_POST['webmail_id'];
				$ver_code=$_POST['ver_code'];
				$new_pass=$_POST['new_pass'];
				$new_pass_again=$_POST['new_pass_again'];
				
				if(!empty($webmail) && !empty($ver_code) && !empty($new_pass) && !empty($new_pass_again))
				{
					$query= "SELECT * FROM `teams` WHERE `email1`= '".$webmail."' AND `vercode`= '".$ver_code."'";
					if($query_run= mysql_query($query)){
								if(mysql_num_rows($query_run)==1)
								{
								if($new_pass==$new_pass_again)
								{
								if(mysql_query("UPDATE  `matrix_exp`.`teams` SET  `pass` =  '".hash("md5", $new_pass)."' WHERE  `teams`.`email1` ='".$webmail."'")){
								$change=1;
								mysql_query("UPDATE  `matrix_exp`.`teams` SET  `vercode` = NULL WHERE  `teams`.`email1` ='".$webmail."'");
								}
																
								}
					}
					}
					}
					}
				
	if($change==1)
		{
		echo 'Your password has been changed successfully. Go to<button onClick= window.location.assign("home") class="btn btn-primary btn-block">HOME</button>';
		
		}
		else{
		echo '<div class="col-md-4" style ="padding:30px">';
		echo 'You made an error while filling up the details.<button onClick= window.location.assign("change_password") class="btn btn-primary btn-block">GO BACK</button>';
		echo '</div>';
		
		}

	

?>

