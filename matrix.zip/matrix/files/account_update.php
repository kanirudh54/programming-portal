<?php
if(isset($_SESSION['loggedin'])){ 
    $query = "select * from teams where tid='".$_SESSION['team']['id']."'";
    $team = DB::findOneFromQuery($query);
?>
<h1>Update Account</h1>
<form class="form-horizontal" role='form' method="post" action="<?php echo SITE_URL; ?>/process.php">
    <hr align='left' width='50%'>
   <div class='col-lg-12'>
            
            <h3>Team Member 1</h3>
            <div class='form-group'>
                <label class='col-lg-2 control-label' for='name1'>Full Name</label>
                <div class='col-lg-4'><input class='form-control' type='text' name='name1' id='name1' value = '<?php echo $team['name1']?>' required <?php
                    if (isset($_SESSION['reg']['name1'])) {
                        echo "value='" . $_SESSION['reg']['name1'] . "' ";
                        unset($_SESSION['reg']['name1']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-2 control-label' for='roll1'>Roll No</label>
                <div class='col-lg-4'><input class='form-control' type='text' name='roll1' id='roll1' value = '<?php echo $team['roll1']?>' required <?php
                    if (isset($_SESSION['reg']['roll1'])) {
                        echo "value='" . $_SESSION['reg']['roll1'] . "' ";
                        unset($_SESSION['reg']['roll1']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-2 control-label' for='branch1'>Branch</label>
                <div class='col-lg-4'><input class='form-control' type='text' name='branch1' id='branch1' value = '<?php echo $team['branch1']?>' required <?php
                    if (isset($_SESSION['reg']['branch1'])) {
                        echo "value='" . $_SESSION['reg']['branch1'] . "' ";
                        unset($_SESSION['reg']['branch1']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-2 control-label' for='email1'>E-mail</label>
                <div class='col-lg-4'><input class='form-control' type='text' name='email1' id='email1' value = '<?php echo $team['email1']?>' required <?php
                    if (isset($_SESSION['reg']['email1'])) {
                        echo "value='" . $_SESSION['reg']['email1'] . "' ";
                        unset($_SESSION['reg']['email1']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-2 control-label' for='phno1'>Phone No</label>
                <div class='col-lg-4'><input class='form-control' type='text' name='phno1' id='phno1' value = '<?php echo $team['phone1']?>' required <?php
                    if (isset($_SESSION['reg']['phno1'])) {
                        echo "value='" . $_SESSION['reg']['phno1'] . "' ";
                        unset($_SESSION['reg']['phno1']);
                    }
                    ?>/></div>
            </div>
        </div>
        <div class='col-lg-6'>
            <h3>Team Member 2</h3>
            <div class='form-group'>
                <label class='col-lg-4 control-label' for='name2'>Full Name</label>
                <div class='col-lg-8'><input class='form-control' type='text' name='name2' id='name2' value = '<?php echo $team['name2']?>' <?php
                    if (isset($_SESSION['reg']['name2'])) {
                        echo "value='" . $_SESSION['reg']['name2'] . "' ";
                        unset($_SESSION['reg']['name2']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-4 control-label' for='roll2'>Roll No</label>
                <div class='col-lg-8'><input class='form-control' type='text' name='roll2' id='roll2' value = '<?php echo $team['roll2']?>' <?php
                    if (isset($_SESSION['reg']['roll2'])) {
                        echo "value='" . $_SESSION['reg']['roll2'] . "' ";
                        unset($_SESSION['reg']['roll2']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-4 control-label' for='branch2'>Branch</label>
                <div class='col-lg-8'><input class='form-control' type='text' name='branch2' id='branch2' value = '<?php echo $team['branch2']?>' <?php
                    if (isset($_SESSION['reg']['branch2'])) {
                        echo "value='" . $_SESSION['reg']['branch2'] . "' ";
                        unset($_SESSION['reg']['branch2']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-4 control-label' for='email2'>E-mail</label>
                <div class='col-lg-8'><input class='form-control' type='text' name='email2' id='email2' value = '<?php echo $team['email2']?>' <?php
                    if (isset($_SESSION['reg']['email2'])) {
                        echo "value='" . $_SESSION['reg']['email2'] . "' ";
                        unset($_SESSION['reg']['email2']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-4 control-label' for='phno2'>Phone No</label>
                <div class='col-lg-8'><input class='form-control' type='text' name='phno2' id='phno2' value = '<?php echo $team['phone2']?>' <?php
                    if (isset($_SESSION['reg']['phno2'])) {
                        echo "value='" . $_SESSION['reg']['phno2'] . "' ";
                        unset($_SESSION['reg']['phno2']);
                    }
                    ?>/></div>
            </div>
        </div>
        <div class='col-lg-6'>
            <h3>Team Member 3</h3>
            <div class='form-group'>
                <label class='col-lg-4 control-label' for='name3'>Full Name</label>
                <div class='col-lg-8'><input class='form-control' type='text' name='name3' id='name3' value = '<?php echo $team['name3']?>' <?php
                    if (isset($_SESSION['reg']['name3'])) {
                        echo "value='" . $_SESSION['reg']['name3'] . "' ";
                        unset($_SESSION['reg']['name3']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-4 control-label' for='roll3'>Roll No</label>
                <div class='col-lg-8'><input class='form-control' type='text' name='roll3' id='roll3' value = '<?php echo $team['roll3']?>' <?php
                    if (isset($_SESSION['reg']['roll3'])) {
                        echo "value='" . $_SESSION['reg']['roll3'] . "' ";
                        unset($_SESSION['reg']['roll3']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-4 control-label' for='branch3'>Branch</label>
                <div class='col-lg-8'><input class='form-control' type='text' name='branch3' id='branch3' value = '<?php echo $team['branch3']?>' <?php
                    if (isset($_SESSION['reg']['branch3'])) {
                        echo "value='" . $_SESSION['reg']['branch3'] . "' ";
                        unset($_SESSION['reg']['branch3']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-4 control-label' for='email3'>E-mail</label>
                <div class='col-lg-8'><input class='form-control' type='text' name='email3' id='email3' value = '<?php echo $team['email3']?>' <?php
                    if (isset($_SESSION['reg']['email3'])) {
                        echo "value='" . $_SESSION['reg']['email3'] . "' ";
                        unset($_SESSION['reg']['email3']);
                    }
                    ?>/></div>
            </div>
            <div class='form-group'>
                <label class='col-lg-4 control-label' for='phno3'>Phone No</label>
                <div class='col-lg-8'><input class='form-control' type='text' name='phno3' id='phno3' value = '<?php echo $team['phone3']?>' <?php
                    if (isset($_SESSION['reg']['phno3'])) {
                        echo "value='" . $_SESSION['reg']['phno3'] . "' ";
                        unset($_SESSION['reg']['phno3']);
                    }
                    ?>/></div>
            </div>
        </div>
        <div class='form-group'>
        <lable class='col-lg-2 control-label'></lable>
        <div class='col-lg-4'>
            <input type="submit" class="btn btn-primary btn-large" value="update account" name="update_info" />
        </div>
    </div>
</form>
For other changes contact admins. 
<?php }
else{
    $_SESSION['msg'] = "You have to be logged in";
    redirectTo("http://" . $_SERVER['HTTP_HOST'] . $_SESSION['url']);
}
?>
