<?php
require_once 'config.php';
require_once 'components.php';
?>
                <!--Checking for android -->
                <?php
                        function mobile_user_agent_switch1(){
                            $device=NULL;
                            if( stristr(strtolower($_SERVER['HTTP_USER_AGENT']),'android') ) {
                                $device = "android";
                            }       
                            if( $device ) {
                                return true;
                            } 
                            return false; 

                        }
                        $xyz=mobile_user_agent_switch1();
                ?>

                <!--check complete -->
<!DOCTYPE html>

   
    <link href="themes/1/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/1/js-image-slider.js" type="text/javascript"></script>
    <!-- <link href="themes/generic.css" rel="stylesheet" type="text/css" /> -->
	

<br/>
<?php if(!$xyz){?>
<div id="sliderFrame">
        <div id="slider">
            <a href='<?php echo SITE_URL; ?>' target="_blank">
                <img src="images/image-slider-6.jpg" alt="Welcome to Matrix" />
            </a>
            <a href='<?php echo SITE_URL; ?>/problems' target="_blank">
            <img src="images/image-slider-2.jpg" alt="Pratice to become better... and Compete to prove yourself..." />
            </a>
            <img src="images/image-slider-81.png" alt="Upcoming contests :: April Lunch Time" />
            <img src="images/image-slider-10.png" alt="Past contests :: April challenge" />
            <!--<img src="images/image-slider-3.jpg" alt="" />-->
        </div>
        
 </div>
 <?php }?>
    <br/>
    <br/>
 
<?php 
//echo "";
if(isset($_SESSION['loggedin']) && $_SESSION['team']['status'] == 'Admin'){
    echo "<a class='btn btn-primary pull-right' style='margin-top: 10px;' href='".SITE_URL."/adminjudge'><i class='glyphicon glyphicon-edit'></i> Edit</a>";
}
echo "<center><h1>Notice</h1></center>";
$query = "select value from admin where variable='notice'";
$result = DB::findOneFromQuery($query);
$data = $result['value'];
$data = str_replace("\r", "", $data);
$data = preg_replace("/\n\n\n*/", "\n\n", $data);
$data = preg_replace("/[\s\n]*$/", "", $data);
$data = explode("\n\n", $data);
foreach ($data as $x) {
    $y = explode("\n", $x);
    if (!isset($y[0]))
        continue;
    if (isset($y[0][0]) and $y[0][0] == "~" and $_SESSION["status"] != "Admin")
        continue;
    if (isset($y[0][0]) and $y[0][0] == "~")
        $y[0] = substr($y[0], 1);
    echo "<br><table class='table table-striped'><tr><th>" . stripslashes($y[0]) . "</th></tr><tr><td style='text-align: justify'><ul>";
    for ($i = 1; $i < count($y); $i++)
        echo "<li>" . stripslashes($y[$i]) . "</li>";
    echo "</ul></td></tr></table>";
    //echo time();
    //echo date('m/d/Y', 1299446702);
    ?>
    <table class='table table-condensed'>
        <tr><th>Active Contests</th><th>Start Time</th><th>End Time</th></tr>
        <?php
        $query = "SELECT * FROM contest";
        $res = DB::findAllFromQuery($query);
        $time = time();
        foreach ($res as $row)
        if($time > $row['starttime'] && $time < $row['endtime'])
        {   
            $a = date("d-M-Y, h:i:s a", $row[starttime]);
            $b = date("d-M-Y, h:i:s a", $row[endtime]);
            echo "<tr><td><a href='" . SITE_URL . "/contests/$row[code]'>$row[name]</a></td><td>$a</td><td>$b</td></tr>";
        }
        ?>
    </table>
    <table class='table table-condensed'>
        <tr><th>Future Contests</th><th>Start Time</th><th>End Time</th></tr>
        <?php
        $query = "SELECT * FROM contest";
        $res = DB::findAllFromQuery($query);
        $time = time();
        foreach ($res as $row)
        if($time < $row['starttime'])
        {
            $a = date("d-M-Y, h:i:s a", $row[starttime]);
            $b = date("d-M-Y, h:i:s a", $row[endtime]);
            echo "<tr><td><a href='" . SITE_URL . "/contests/$row[code]'>$row[name]</a></td><td>$a</td><td>$b</td></tr>";
        }
        ?>
    </table>
    <?php
}
?>
