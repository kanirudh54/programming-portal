<center>
<div class="row" >
	<div class="col-md-4" style ="padding:20px">
		<div class="input-group" style="margin-bottom: -1px;">
		<form class="diff_forms" action="ver_code" method="POST">
		<p>GET VERIFICATION CODE NOW</p><br>
		<input class="form-control" style="border-bottom-right-radius: 0;" type="text" placeholder="email" name="get_webmail" /><br>
		<input id="signup" type="submit" value="GET IT NOW" class="btn btn-primary btn-block"/>
		</form>
		</div>
	</div>
	<div class="col-md-2">
	</div>
	<div class="col-md-4" style ="padding:20px">
		
			
		<div class="input-group" style="margin-bottom: -1px;">
		<form class="diff_forms" action="new_password" method="POST">
			<p>GOT YOUR VERIFICATION CODE?</p><br>
					<input class="form-control" style="border-bottom-right-radius: 0;"  placeholder="email" name="webmail_id" type="text" /><br>
		<input class="form-control" style="border-bottom-right-radius: 0;"  placeholder="Verification Code" name="ver_code" type="text" /><br>
		<input class="form-control" style="border-bottom-right-radius: 0;"   placeholder="New Password" name="new_pass" type="password"/><br>
		<input class="form-control" style="border-bottom-right-radius: 0;"  placeholder="Re-Enter New Password"name="new_pass_again" type="password" /><br><br>
		<input id="signup" type="submit" value="CHANGE PASSWORD" class="btn btn-primary btn-block"/>
		
		</form>
		
		</div>
	</div>
</div>	
</center>



