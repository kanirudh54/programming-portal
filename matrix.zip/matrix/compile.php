<?php
 
require_once 'config.php';

if($judge['value']!="Lockdown"){  // table with layout rid,lang,code,input,output,error,submittime,timetaken    and name anon_run
  if(isset($_POST['compile'])){  // POST compile code lang input  MAKE a page viewresult.php
    $code=$_POST['code'];
    $code=addslashes($code);
    $language=$_POST['language'];
    $input=$_POST['input'];
    $team_id=$_POST['team_id'];
    $submittime=time();
    $insert_query="insert into anon_run (language,code,input,submittime,tid) values ('".$language."','".$code."','".$input."',".$submittime.",'" . $team_id."');";
    DB::query($insert_query);
    $rid_query="select rid from anon_run where submittime=".$submittime.";";
    $rid_query_exec=DB::findOneFromQuery($rid_query);
    if($rid_query_exec){
      $_SESSION['msg'] = "Code submitted successfully. If your problem is not judged then contact admin.";
            $query = "select * from admin where variable ='mode' or variable ='endtime' or variable='ip' or variable ='port'";
            $check = DB::findAllFromQuery($query);
            $admin = Array();
            foreach ($check as $row) {
                $admin[$row['variable']] = $row['value'];
            }
            $rid=$rid_query_exec['rid'];
            $client = stream_socket_client($admin['ip'] . ":" . $admin['port'], $errno, $errorMessage);
            if ($client === false) {
                 $_SESSION["msg"] .= "<br/>Cannot connect to Judge: Contact Admin";
            }
            fwrite($client, "com".$rid);
            fclose($client);
            //echo var_dump($client);
            redirectTo(SITE_URL . "/viewresult/" . $rid);
    } else {
       $_SESSION['msg'] = "Database Error.";
       echo var_dump($insert_query);
      // redirectTo("http://" . $_SERVER['HTTP_HOST'] . $_SESSION['url']);
    }
  }

}
else{
  $_SESSION['msg'] = "Judge is in Lockdown mode and so no requests are being processed.";
  redirectTo("http://" . $_SERVER['HTTP_HOST'] . $_SESSION['url']);
}

