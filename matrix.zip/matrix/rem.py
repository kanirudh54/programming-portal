#!/usr/bin/python
import os,sys
'''if(len(sys.argv)>=2):
	dr=sys.argv[1]
	os.system("rm -f judge/io_cache/"+str(dr)+"/*");
	#print "rm -f judge/io_cache/"+str(dr)+"/*"
else:'''
fl=open("in.txt","w")
fl.write(sys.argv[1])
os.system("rm -f ./judge/io_cache/"+"Input_"+str(sys.argv[1])+"*");
os.system("rm -f ./judge/io_cache/"+"Output_"+str(sys.argv[1])+"*");
fl.close()
#os.system("rm -f judge/io_cache/in.txt")
